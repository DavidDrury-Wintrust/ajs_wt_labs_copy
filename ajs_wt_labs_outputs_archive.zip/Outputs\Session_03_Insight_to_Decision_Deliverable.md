# Hands-on Lab 3 Deliverable: Insight to Decision

## Executive Snapshot

This portfolio shows strong top-line conversion but weak forecast reliability. Revenue realization is concentrated in specific region-product pockets, while North region cells and probability-scoring behavior indicate structural execution and governance gaps.

### KPI Dashboard

| KPI | Value | Executive Read |
|---|---:|---|
| Total Deals | 300 | Sufficient sample for directional decisions |
| Total Pipeline | INR 1,388,100,000 | Large commercial base |
| Actual Revenue | INR 1,059,400,000 | Strong realized topline |
| Revenue / Pipeline | 76.3% | Good monetization overall |
| Win Rate | 98.7% (296/300) | Likely inflated by data semantics |
| Avg Sales Cycle | 85.5 days | Manageable but uneven by region |
| High-Risk Deal Share | 18.0% | Risk concentration requires controls |
| Deals with Revenue > Pipeline | 120 (40.0%) | Major planning and data-governance concern |

## Evidence Table

| Theme | Evidence | Decision Implication |
|---|---|---|
| Regional monetization gap | South Rev/Pipe 81.5%, East 81.3%, North 71.5%, West 70.6% | Prioritize scaling East/South playbooks; treat North/West as performance recovery zones. |
| Regional speed and risk | South avg cycle 79.5 days (fastest), North 93.0 days (slowest), East high-risk share 21.4% | North needs cycle-compression actions; East performance is resilient but risk-heavy. |
| Product economics | Cloud Ops Rev/Pipe 79.4% (best), Data Platform 77.8%, Analytics 76.4%, Security Services 74.5%, Digital Payments 74.4% | Cloud Ops is a growth engine but must be governed for volatility. |
| Product risk concentration | High-risk share: Cloud Ops 26.7% (highest) vs Data Platform 12.0% (lowest) | Pair growth bets with tighter risk gating in Cloud Ops. |
| Segment spread | Enterprise Rev/Pipe 80.8%, SMB 76.2%, Mid-Market 72.6% | Mid-Market deal quality and qualification should be a targeted improvement program. |
| Probability calibration | Rev/Pipe by WinProb: 0.20 -> 82.7%, 0.35 -> 81.9%, 0.50 -> 71.5%, 0.65 -> 70.3%, 0.80 -> 74.1% | Scoring does not rank outcomes reliably; forecasting model needs recalibration. |
| Data consistency signal | correlation(WinProb, Revenue/Pipeline) = -0.105 | Probability signal is weak-to-inverted; do not rely on score alone for commit plans. |
| Monthly volatility | Best month: 2026-05 Rev/Pipe 92.5%; weakest: 2026-04 Rev/Pipe 63.4% | Improve operating cadence with month-level quality gates and early pipeline hygiene checks. |
| Best opportunity pocket 1 | East + Security Services: 13 deals, Rev/Pipe 120.3% | Replicate pricing and qualification pattern across adjacent territories. |
| Best opportunity pocket 2 | South + Data Platform: 7 deals, Rev/Pipe 119.0% | Increase pipeline coverage in this high-yield combination. |
| Highest risk pocket 1 | North + Data Platform: 9 deals, Rev/Pipe 46.9%, avg cycle 106.8 days | Deploy recovery interventions: qualification reset, stage discipline, executive deal reviews. |
| Highest risk pocket 2 | North + Analytics: 13 deals, Rev/Pipe 55.7%, avg cycle 107.6 days | Focused turnaround needed to reduce cycle drag and improve conversion quality. |

## Three Meaningful Insights

1. Regional execution is not uniform: East and South outperform North and West by about 10 percentage points on revenue realization.
2. Segment economics are imbalanced: Enterprise is strongest while Mid-Market lags and is the clearest improvement target.
3. Forecast inputs are not trustworthy as currently configured: lower probability bands outperform higher bands, indicating scoring and process misalignment.

## Two Potential Risks

1. Forecast governance risk: exceptionally high win rates combined with frequent revenue > pipeline outcomes can distort commits and capacity planning.
2. Concentration risk in underperforming cells: North Data Platform and North Analytics combine low realization with long cycles, threatening quarter-end predictability.

## Two Potential Opportunities

1. Scale winning pockets: expand demand and replication in East Security Services and South Data Platform.
2. Lift overall yield via Mid-Market redesign: tighten qualification criteria, improve solution packaging, and standardize stage-exit controls.

## Challenge to Findings

1. Challenge the "high overall performance" narrative: 98.7% win rate likely reflects dataset semantics rather than true competitive close rates.
2. Challenge the "regional execution only" narrative: East/South advantage may be partially product-mix and deal-size mix effects, not purely sales behavior.

## Executive Recommendation

Launch a **60-day Forecast Reliability + Conversion Lift Program** with two coordinated tracks.

### Track A: Governance and Forecast Quality

| Action | Owner | Outcome Target |
|---|---|---|
| Recalibrate win-probability model and update scoring rules | RevOps + Sales Ops | Probability bands become directionally monotonic by realized performance |
| Enforce pipeline-to-revenue variance controls | Finance + Sales Leadership | Reduced outlier variance; improved planning confidence |
| Weekly forecast hygiene review for top-deal outliers | Regional Leaders | Early detection of commit-risk deals |

### Track B: Growth and Performance Replication

| Action | Owner | Outcome Target |
|---|---|---|
| Codify and replicate East Security Services and South Data Platform playbooks | GTM Strategy + Regional Heads | Expand high-yield patterns into adjacent territories |
| Create North recovery squad for Data Platform and Analytics | CRO Office + North Leader | Shorter cycle time and higher revenue realization |
| Mid-Market qualification reset and stage-exit hard gates | Sales Excellence Team | Improved deal quality and conversion efficiency |

### Next-Quarter Success Metrics

1. Raise Mid-Market Rev/Pipe from 72.6% to at least 77.0%.
2. Reduce North average cycle from 93.0 days to below 85.0 days.
3. Restore scoring credibility by achieving monotonic revenue realization across probability bands.

## Five Follow-up Questions

1. How are win-probability scores currently generated, and what is the refresh cadence by stage?
2. Which policy or process allows revenue to exceed pipeline value, and what variance thresholds are approved?
3. Which stages and reasons dominate shortfalls in North Data Platform and North Analytics deals?
4. How much of East/South outperformance is explained by product mix, deal size, discounting, and channel structure?
5. Which teams and managers own the best and worst cells, and what process differences can be standardized?
